# Whats-Guru — correção de mensagens enviadas + diagnóstico de PDF

## O que muda
- Mensagens enviadas pelo WhatsApp conectado (`fromMe: true`) passam a ser importadas como `sender_type: agent`, inclusive imagens e documentos.
- Mensagens enviadas pelo próprio painel (já registradas em `webhook_events`) são ignoradas na reimportação, para evitar duplicações normais.
- Mensagens enviadas não aumentam a contagem de não lidas nem disparam automações de entrada.
- Para eventos descartados, o backend informa **somente** tipo de JID e tipo de mensagem, sem telefone, texto, URLs ou chaves.
- Não altera os filtros de grupos, status e transmissões.

## Instalação
1. Backup dos dois arquivos originais.
2. Extrair ZIP na raiz do projeto e substituir os dois arquivos.
3. Reiniciar backend em `server` com `npm run dev`.
4. Enviar texto e imagem **do celular conectado** para um contato e abrir a conversa correspondente no Whats-Guru.
5. Enviar PDF **de outro celular** diretamente ao número conectado.
6. Copiar apenas `[Evolution Sync]`, `[Evolution Webhook]` e `[Evolution Diagnostico]` do terminal. Não compartilhar payloads com dados pessoais.

Não é necessária migração SQL nem `prisma generate`.

## Limitações
- O histórico da Evolution é consultado em blocos de 50 mensagens recentes. Não equivale a importar todos os anos de histórico.
- A prevenção de duplicação usa o registro de envio do painel; uma corrida entre o webhook e o registro do envio pode gerar duplicata rara. Requer reconciliação por ID do provedor numa etapa posterior.
- PDFs não são considerados corrigidos até sabermos se o evento recebido é realmente um `documentMessage` privado. `ignored_non_private` pode ser um status/transmissão não relacionado ao PDF.
- Não altera o armazenamento permanente de arquivos.
