# Whats-Guru — Temas Escuro e Claro

Esta atualização modifica **somente o frontend e as cores**. Ela não inclui arquivos de `server/`, não cria rotas, não executa scripts e não altera banco, Prisma, automações nem a estrutura das telas.

## Instalação

1. Faça uma cópia dos arquivos atuais e um commit/backup antes da instalação.
2. Extraia este ZIP na **raiz** do projeto Whats-Guru, preservando as pastas `src/` e substituindo os arquivos correspondentes. O arquivo `tailwind.config.js` fica na raiz.
3. Na raiz do projeto, execute:

```powershell
npm run dev
```

4. Atualize o navegador com `Ctrl + Shift + R`.

## Como trocar

No menu do usuário (parte inferior da barra lateral), use **Tema claro** ou **Tema escuro**. O padrão é **escuro**, mesmo se o Windows estiver em modo claro. A preferência fica armazenada **somente nesse navegador** (`localStorage`), sem endpoint e sem mudança no cadastro do usuário.

## Paleta

- Preto Imports: `#1A1A1A`
- Aço: `#5C5C5C`
- Âmbar: `#FFC734`
- Papel: `#F2F2F0`
- Âmbar Profundo: `#B8871A`

Fundos e textos neutros usam variações tonais desses valores. Cores de estado (erro, alerta, sucesso) e cores personalizadas das etiquetas permanecem diferenciadas para manter sua finalidade e legibilidade. QR Code mantém fundo claro para ser escaneável.

## Validação sugerida

Faça testes visuais, alternando os dois temas, em Login, Painel, Caixa de Entrada, Contatos, Kanban, Chatbots, Automações, Campanhas, Agendamentos, Relatórios, Equipe, Integrações, Perfil, menus e modais. Confira que textos, controles e ícones continuam legíveis e que as ações funcionam como antes.

Esta entrega teve verificação sintática estática dos arquivos TSX; **não foi possível executar o build completo com as dependências do seu projeto nem teste visual em navegador neste ambiente**. Não foi alterado nenhum arquivo do backend.
